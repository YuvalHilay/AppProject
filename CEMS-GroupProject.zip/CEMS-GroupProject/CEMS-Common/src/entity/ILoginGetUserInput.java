package entity;



public interface ILoginGetUserInput {
    public String getUserID();



    public String getUserPassword();
    public String getUserRole();



    String geteErrorMsg();
}