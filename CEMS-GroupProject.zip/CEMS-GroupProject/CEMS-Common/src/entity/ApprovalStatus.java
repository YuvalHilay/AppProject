package entity;

/**
 * Represents the approval status for a request.
 */
public enum ApprovalStatus {
    YES, NO
}
