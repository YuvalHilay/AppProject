package entity;

/**
 * represents the type of test
 * C - Computerized
 * M - Manual
 */
public enum TestTypeEnum {
    C, M
}
