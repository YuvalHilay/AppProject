package entity;

/**
 * Represents the suspicion of cheating.
 */
public enum CheatingSuspicion {
    YES, NO
}
